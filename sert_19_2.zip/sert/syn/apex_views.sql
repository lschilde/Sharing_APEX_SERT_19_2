PROMPT == WWV_FLOW_SESSIONS$

set concat off
CREATE OR REPLACE VIEW  ^parse_as_user.sv_sec_apex_sessions_v AS SELECT * FROM ^esert_user.sv_sec_apex_sessions_v
/
set concat on
