set define '^'

PROMPT ==
PROMPT == Tables
PROMPT ==
@syn/tables.sql 

PROMPT ==
PROMPT == Views
PROMPT ==
@syn/views.sql 

PROMPT ==
PROMPT == Pacakges
PROMPT ==
@syn/packages.sql 


PROMPT ==
PROMPT == APEX Views
PROMPT ==
--@syn/apex_views.sql 